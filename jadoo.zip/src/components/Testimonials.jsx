import { useState, useEffect } from "react";
import ASSETS from "../assets";
import "./Testimonials.css";

const TESTIMONIALS = [
  {
    avatar: ASSETS.avatar1,
    text: '"On the Windows talking painted pasture yet its express parties use. Sure last upon he same as knew next. Of believed or diverted no."',
    name: "Chris Thomas",
    role: "CEO of Red Button",
  },
  {
    avatar: ASSETS.avatar2,
    text: '"After going through a number of sites, I had to settle for Jadoo because honestly it was a no brainer trying someone else."',
    name: "Sarah Connor",
    role: "Globetrotter",
  },
  {
    avatar: ASSETS.avatar3,
    text: '"On the Windows talking painted pasture yet its express parties use. Sure last upon he same as knew next. Of believed or diverted no."',
    name: "Mike Taylor",
    role: "Lahore, Pakistan",
  },
];

function ArrowUp({ onClick }) {
  return (
    <button className="swiper-arrow" onClick={onClick} aria-label="Previous slide">
      <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
        <path
          d="M7 11V3M3 7L7 3L11 7"
          stroke="#5E6282"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </button>
  );
}

function ArrowDown({ onClick }) {
  return (
    <button className="swiper-arrow swiper-arrow--active" onClick={onClick} aria-label="Next slide">
      <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
        <path
          d="M7 3V11M11 7L7 11L3 7"
          stroke="#fff"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </button>
  );
}

export default function Testimonials() {
  const [current, setCurrent] = useState(0);
  const total = TESTIMONIALS.length;

  const prev = () => setCurrent((c) => (c - 1 + total) % total);
  const next = () => setCurrent((c) => (c + 1) % total);

  useEffect(() => {
    const id = setInterval(next, 5000);
    return () => clearInterval(id);
  }, []);

  return (
    <section className="testimonials__section">
      <div className="container-large">
        <div className="testimonials__left">
          <p className="testimonials__pre-text">Testimonials</p>
          <h2 className="testimonials__title">
            What People Say
            <br />
            About Us
          </h2>
        </div>

        <div className="testimonials__right">
          <div className="swiper-testimonial">
            <div
              className="swiper-testimonial__track"
              style={{ transform: `translateX(-${current * 100}%)` }}
            >
              {TESTIMONIALS.map((t, i) => (
                <div key={i} className="swiper-testimonial__slide">
                  <div className="testimonial-card">
                    <img
                      src={t.avatar}
                      alt={t.name}
                      className="testimonial-card__avatar"
                    />
                    <p className="testimonial-card__text">{t.text}</p>
                    <h4 className="testimonial-card__name">{t.name}</h4>
                    <p className="testimonial-card__role">{t.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="swiper-testimonial__arrows">
            <ArrowUp onClick={prev} />
            <ArrowDown onClick={next} />
          </div>
        </div>
      </div>
    </section>
  );
}
