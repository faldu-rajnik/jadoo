import ASSETS from "../assets";
import "./Services.css";

const SERVICES = [
  {
    icon: ASSETS.weatherIcon,
    title: "Calculated Weather",
    text: "Built Wicket longer admire do barton vanity itself do in it.",
  },
  {
    icon: ASSETS.flightsIcon,
    title: "Best Flights",
    text: "Engrossed listening. Park gate sell they west hard for the.",
  },
  {
    icon: ASSETS.eventsIcon,
    title: "Local Events",
    text: "Barton vanity itself do in it. Prefferd to men it engrossed listening.",
  },
  {
    icon: ASSETS.customIcon,
    title: "Customization",
    text: "We deliver outsourced aviation services for military customers.",
  },
];

export default function Services() {
  return (
    <section className="services__section">
      <div className="container-large">
        <p className="services__pre-text">Category</p>
        <h2 className="services__title">We Offer Best Services</h2>

        <div className="services__grid">
          {SERVICES.map((s) => (
            <div key={s.title} className="service-card">
              <div className="service-card__icon">
                <img src={s.icon} alt={s.title} />
              </div>
              <h3 className="service-card__title">{s.title}</h3>
              <p className="service-card__text">{s.text}</p>
              <div className="service-card__dot" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
