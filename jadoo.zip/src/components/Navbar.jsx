import { useState } from "react";
import "./Navbar.css";
import ASSETS from "../assets";

const NAV_LINKS = ["Destinations", "Hotels", "Flights", "Bookings", "Logins"];

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="nav__wrapper">
      <div className="container-large">
        <a href="#" className="nav__logo">
          <img src={ASSETS.logo} alt="Jadoo" />
        </a>

        <nav className="nav__menu">
          {NAV_LINKS.map((link) => (
            <a key={link} href="#" className="nav__link">{link}</a>
          ))}
          <a href="#" className="nav__link nav__link--btn">Sign up</a>
          <a href="#" className="nav__link">EN</a>
        </nav>

        <div
          className="nav__hamburger"
          onClick={() => setMenuOpen((o) => !o)}
          aria-label="Toggle menu"
        >
          <span />
          <span />
          <span />
        </div>
      </div>

      <div className={`nav__mobile-menu${menuOpen ? " open" : ""}`}>
        {NAV_LINKS.map((link) => (
          <a key={link} href="#" className="nav__link">{link}</a>
        ))}
        <a href="#" className="nav__link nav__link--btn">Sign up</a>
        <a href="#" className="nav__link">EN</a>
      </div>
    </header>
  );
}
