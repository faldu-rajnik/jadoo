import ASSETS from "../assets";
import "./Footer.css";

const COMPANY_LINKS = ["About", "Careers", "Mobile"];
const CONTACT_LINKS = ["Help / FAQ", "Press", "Affiliates"];
const MORE_LINKS = ["Airline fees", "Airline", "Low fare tips"];

const SOCIAL_LINKS = [
  { src: ASSETS.facebook, alt: "Facebook" },
  { src: ASSETS.instagram, alt: "Instagram" },
  { src: ASSETS.twitter, alt: "Twitter" },
];

export default function Footer() {
  return (
    <footer className="footer__section">
      <div className="container-large">
        <div className="footer__grid">
          {/* Brand */}
          <div>
            <div className="footer__brand">Jadoo.</div>
            <p className="footer__tagline">
              Book your trip in minute, get full
              <br />
              control for much longer.
            </p>
          </div>

          {/* Company */}
          <div>
            <h4 className="footer__col-title">Company</h4>
            <div className="footer__links">
              {COMPANY_LINKS.map((l) => (
                <a key={l} href="#" className="footer__link">{l}</a>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="footer__col-title">Contact</h4>
            <div className="footer__links">
              {CONTACT_LINKS.map((l) => (
                <a key={l} href="#" className="footer__link">{l}</a>
              ))}
            </div>
          </div>

          {/* More */}
          <div>
            <h4 className="footer__col-title">More</h4>
            <div className="footer__links">
              {MORE_LINKS.map((l) => (
                <a key={l} href="#" className="footer__link">{l}</a>
              ))}
            </div>
          </div>

          {/* Social + Apps */}
          <div>
            <div className="footer__socials">
              {SOCIAL_LINKS.map((s) => (
                <a key={s.alt} href="#" className="footer__social-link">
                  <img src={s.src} alt={s.alt} />
                </a>
              ))}
            </div>
            <p className="footer__app-label">Discover our app</p>
            <div className="footer__apps">
              <img src={ASSETS.googlePlay} alt="Google Play" />
              <img src={ASSETS.appStore} alt="App Store" />
            </div>
          </div>
        </div>

        <div className="footer__bottom">All rights reserved@jadoo.co</div>
      </div>
    </footer>
  );
}
