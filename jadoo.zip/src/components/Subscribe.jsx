import { useState } from "react";
import "./Subscribe.css";
import sendIcon from "../assets/images/send-now.png";
import plusGfx from "../assets/images/plus-graphics.svg";

export default function Subscribe() {
  const [email, setEmail] = useState("");

  return (
    <section className="subscribe__section">
      <div className="container-large">
        <div className="subscribe__card">

          <img src={sendIcon} alt="Send" className="subscribe__send-icon" />
          <img src={plusGfx} alt="" className="subscribe__plus-gfx" aria-hidden="true" />

          <h3 className="subscribe__title">
            Subscribe to get information,
            <br />
            latest news and other interesting
            <br />
            offers about Cobham
          </h3>

          <div className="subscribe__form">
            <div className="subscribe__input-wrap">
              <svg className="subscribe__input-icon" width="18" height="14" viewBox="0 0 18 14" fill="none">
                <path d="M1 1H17M1 1L9 8L17 1M1 1V13H17V1" stroke="#aaa" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <input
                type="email"
                placeholder="Your email"
                className="subscribe__input"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <button className="subscribe__btn">Subscribe</button>
          </div>

        </div>
      </div>
    </section>
  );
}
