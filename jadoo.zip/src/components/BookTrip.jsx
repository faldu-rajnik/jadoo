import ASSETS from "../assets";
import "./BookTrip.css";

const STEPS = [
  {
    icon: ASSETS.iconChoose,
    color: "orange",
    title: "Choose Destination",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Urna, tortor tempus.",
  },
  {
    icon: ASSETS.iconPayment,
    color: "red",
    title: "Make Payment",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Urna, tortor tempus.",
  },
  {
    icon: ASSETS.iconAirport,
    color: "blue",
    title: "Reach Airport on Date",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Urna, tortor tempus.",
  },
];

export default function BookTrip() {
  return (
    <section className="book__section">
      <div className="container-large">
        <div className="book__left">
          <p className="book__pre-text">Easy and Fast</p>
          <h2 className="book__title">
            Book your Next Trip
            <br />
            in 3 Easy steps
          </h2>

          <div className="book__steps">
            {STEPS.map((s) => (
              <div key={s.title} className="book__step">
                <div className={`book__step-icon book__step-icon--${s.color}`}>
                  <img src={s.icon} alt={s.title} />
                </div>
                <div>
                  <h4 className="book__step-title">{s.title}</h4>
                  <p className="book__step-text">{s.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="book__right">
          <img src={ASSETS.greeceCard} alt="Trip to Greece" className="book__greece-img" />
          <img src={ASSETS.romeCard} alt="Trip to Rome" className="book__rome-img" />
        </div>
      </div>
    </section>
  );
}
