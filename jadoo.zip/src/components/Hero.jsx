import ASSETS from "../assets";
import "./Hero.css";

export default function Hero() {
  return (
    <section className="hero__section">
      <div className="container-large">
        <div className="hero__content">
          <p className="hero__pre-text">Best destinations around the world</p>
          <h1 className="hero__title">
            Travel, <span>enjoy</span>
            <br />and live a new
            <br />and full life
          </h1>
          <p className="hero__desc">
            Built Wicket longer admire do barton vanity itself do in it.
            Preferred to sportsmen it engrossed listening. Park gate sell
            they west hard for the.
          </p>
          <div className="hero__actions">
            <a href="#" className="hero__btn">Find out more</a>
            <div className="hero__play">
              <div className="hero__play-btn">
                <svg width="16" height="18" viewBox="0 0 16 18" fill="none">
                  <path d="M1 1L15 9L1 17V1Z" fill="white" />
                </svg>
              </div>
              <span className="hero__play-text">Play Demo</span>
            </div>
          </div>
        </div>

        <div className="hero__image">
          <img src={ASSETS.womanPlanes} alt="Traveling lady with luggage" />
        </div>
      </div>
    </section>
  );
}
