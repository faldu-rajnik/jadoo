import ASSETS from "../assets";
import "./Logos.css";

const LOGOS = [
  { src: ASSETS.logoAxon, alt: "Axon" },
  { src: ASSETS.logoJetstar, alt: "Jetstar" },
  { src: ASSETS.logoExpedia, alt: "Expedia" },
  { src: ASSETS.logoQantas, alt: "Qantas" },
  { src: ASSETS.logoAlitalia, alt: "Alitalia" },
];

export default function Logos() {
  return (
    <div className="logos__section">
      <div className="container-large">
        <div className="logos__grid">
          {LOGOS.map((l) => (
            <div key={l.alt} className="logos__item">
              <img src={l.src} alt={l.alt} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
