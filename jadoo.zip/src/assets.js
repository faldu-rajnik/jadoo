import logo from "./assets/images/logo.svg";
import womanPlanes from "./assets/images/woman-planes.png";
import weatherIcon from "./assets/images/calculated-weather.svg";
import flightsIcon from "./assets/images/best-flights.svg";
import eventsIcon from "./assets/images/local-events.png";
import customIcon from "./assets/images/customization.svg";
import romeImg from "./assets/images/rome.jpg";
import londonImg from "./assets/images/london.jpg";
import macedoniaImg from "./assets/images/macedonia.jpg";
import locationIcon from "./assets/images/location-mark.svg";
import iconChoose from "./assets/images/icon-chosedestination.svg";
import iconPayment from "./assets/images/icon-makepayment.svg";
import iconAirport from "./assets/images/icon-reachairport.svg";
import romeCard from "./assets/images/trip-to-rome.png";
import greeceCard from "./assets/images/trip-to-greece.png";
import avatar1 from "./assets/images/avatar1.png";
import avatar2 from "./assets/images/avatar2.png";
import avatar3 from "./assets/images/avatar3.png";
import logoAxon from "./assets/images/logo-avon.png";
import logoJetstar from "./assets/images/logo-jetstar.png";
import logoExpedia from "./assets/images/logo-expedia.png";
import logoQantas from "./assets/images/logo-qantas.png";
import logoAlitalia from "./assets/images/logo-alitalia.png";
import facebook from "./assets/images/social-facebook.svg";
import instagram from "./assets/images/social-instagram.png";
import twitter from "./assets/images/social-twitter.svg";
import googlePlay from "./assets/images/google-play.svg";
import appStore from "./assets/images/play-store.svg";

const ASSETS = {
  logo,
  womanPlanes,
  weatherIcon,
  flightsIcon,
  eventsIcon,
  customIcon,
  romeImg,
  londonImg,
  macedoniaImg,
  locationIcon,
  iconChoose,
  iconPayment,
  iconAirport,
  romeCard,
  greeceCard,
  avatar1,
  avatar2,
  avatar3,
  logoAxon,
  logoJetstar,
  logoExpedia,
  logoQantas,
  logoAlitalia,
  facebook,
  instagram,
  twitter,
  googlePlay,
  appStore,
};

export default ASSETS;
