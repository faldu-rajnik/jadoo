import "./index.css";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Services from "./components/Services";
import Destinations from "./components/Destinations";
import BookTrip from "./components/BookTrip";
import Testimonials from "./components/Testimonials";
import Logos from "./components/Logos";
import Subscribe from "./components/Subscribe";
import Footer from "./components/Footer";

export default function App() {
  return (
    <>
      <div className="hero__bg">
        <Navbar />
        <Hero />
      </div>
      <main>
        <Services />
        <Destinations />
        <BookTrip />
        <Testimonials />
        <Logos />
        <Subscribe />
      </main>
      <Footer />
    </>
  );
}
